#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    double originalPrice, markupPercentage, salesTaxRate;
    
    // Get user input
    cout << "Enter the original price of the item: $";
    cin >> originalPrice;
    
    cout << "Enter the markup percentage: ";
    cin >> markupPercentage;
    
    cout << "Enter the sales tax rate: ";
    cin >> salesTaxRate;
    
    // Calculate selling price after markup
    double sellingPrice = originalPrice + (originalPrice * (markupPercentage / 100));
    
    // Calculate sales tax
    double salesTax = sellingPrice * (salesTaxRate / 100);
    
    // Calculate final price
    double finalPrice = sellingPrice + salesTax;
    
    // Display results
    cout << fixed << setprecision(2);
    cout << "\nOriginal Price: $" << originalPrice << endl;
    cout << "Markup Percentage: " << markupPercentage << "%" << endl;
    cout << "Selling Price: $" << sellingPrice << endl;
    cout << "Sales Tax Rate: " << salesTaxRate << "%" << endl;
    cout << "Sales Tax: $" << salesTax << endl;
    cout << "Final Price: $" << finalPrice << endl;

    return 0;
}
